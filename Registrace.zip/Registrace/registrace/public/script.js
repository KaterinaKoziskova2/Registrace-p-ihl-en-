document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('registrationForm');
    const usernameInput = document.getElementById('username');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const errorContainer = document.getElementById('errorContainer');

    form.addEventListener('submit', function (event) {
        event.preventDefault();
        const errors = [];

        const username = usernameInput.value.trim();
        if (!/^[a-zA-Z0-9]+$/.test(username)) {
            errors.push('Uživatelské jméno může obsahovat pouze alfanumerické znaky.');
        }

        const email = emailInput.value.trim();
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            errors.push('Zadejte platnou e-mailovou adresu ve formátu aaa@bbb.ccc.');
        }

        const password = passwordInput.value;
        if (password.length < 8) {
            errors.push('Heslo musí být alespoň 8 znaků dlouhé.');
        } else {
            const hasLowerCase = /[a-z]/.test(password);
            const hasUpperCase = /[A-Z]/.test(password);
            const hasNumber = /[0-9]/.test(password);
            const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

            const conditionsMet = [hasLowerCase, hasUpperCase, hasNumber, hasSpecialChar].filter(Boolean).length;

            if (conditionsMet < 2 && password.length <= 16) {
                errors.push('Heslo musí obsahovat alespoň dvě z následujících: malé písmeno, velké písmeno, číslo, speciální znak nebo být delší než 16 znaků.');
            }
        }

        const confirmPassword = confirmPasswordInput.value;
        if (password !== confirmPassword) {
            errors.push('Hesla se neshodují.');
        }

        if (errors.length > 0) {
            errorContainer.innerHTML = errors.map(error => `<p>${error}</p>`).join('');
            errorContainer.style.display = 'block';
        } else {
            errorContainer.style.display = 'none';
            form.submit();
        }
    });
});
