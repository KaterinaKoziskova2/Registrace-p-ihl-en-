const express = require('express');
const bodyParser = require('body-parser');
const { check, validationResult } = require('express-validator');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, '../public')));

const usersFilePath = path.join(__dirname, '../data/users.json');

const loadUsers = () => {
    if (!fs.existsSync(usersFilePath)) {
        return [];
    }
    const data = fs.readFileSync(usersFilePath, 'utf8');
    return JSON.parse(data);
};

const saveUsers = (users) => {
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
};

app.post('/register', [
    check('username')
        .isAlphanumeric().withMessage('Uživatelské jméno může obsahovat pouze alfanumerické znaky.')
        .custom((value) => {
            const users = loadUsers();
            const userExists = users.some(user => user.username === value);
            if (userExists) {
                throw new Error('Uživatelské jméno je již obsazeno.');
            }
            return true;
        }),
    check('email')
        .isEmail().withMessage('Zadejte platnou e-mailovou adresu ve formátu aaa@bbb.ccc.')
        .custom((value) => {
            const users = loadUsers();
            const emailExists = users.some(user => user.email === value);
            if (emailExists) {
                throw new Error('E-mailová adresa je již použita.');
            }
            return true;
        }),
    check('password')
        .isLength({ min: 8 }).withMessage('Heslo musí být alespoň 8 znaků dlouhé.')
        .custom((value) => {
            const hasLowerCase = /[a-z]/.test(value);
            const hasUpperCase = /[A-Z]/.test(value);
            const hasNumber = /[0-9]/.test(value);
            const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(value);

            const conditionsMet = [hasLowerCase, hasUpperCase, hasNumber, hasSpecialChar].filter(Boolean).length;

            if (conditionsMet < 2 && value.length <= 16) {
                throw new Error('Heslo musí obsahovat alespoň dvě z následujících: malé písmeno, velké písmeno, číslo, speciální znak nebo být delší než 16 znaků.');
            }
            return true;
        }),
    check('confirmPassword')
        .custom((value, { req }) => {
            if (value !== req.body.password) {
                throw new Error('Hesla se neshodují.');
            }
            return true;
        })
], (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { username, email, password } = req.body;
    const users = loadUsers();
    users.push({ username, email, password });
    saveUsers(users);

    res.status(200).send('Registrace byla úspěšná!');
});

app.listen(PORT, () => {
    console.log(`Server běží na adrese http://localhost:${PORT}`);
});
